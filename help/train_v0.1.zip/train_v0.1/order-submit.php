<?php 
session_start();
header('Content-Type: text/html; charset=utf-8');
require 'model/TrainApi.php';

// 校验订单
if ($_GET['action'] == 'checkOrder') {
  
  $param = $_POST;
  $param['session'] = $_SESSION['session'];
  $param['seat']    = implode(',', $param['seat']);
  $param['type']    = implode(',', $param['type']);
  $param['name']    = implode(',', $param['name']);
  $param['id_type'] = implode(',', $param['id_type']);
  $param['id_no']   = implode(',', $param['id_no']);
  $train = new TrainApi();
  $train->method('train/Order/checkOrder');
  $data = $train->action($param);
  echo json_encode($data);
  exit();
}

// 余票队列
if ($_GET['action'] == 'queueCount') {
  $param = $_POST;
  $param['session'] = $_SESSION['session'];
  
  $train = new TrainApi();
  $train->method('train/Order/queueCount');
  $data = $train->action($param);
  echo json_encode($data);
  exit();
}

// 确认提交
if ($_GET['action'] == 'confirm') {

  $param = $_POST;
  $param['session'] = $_SESSION['session'];
  $param['seat']    = implode(',', $param['seat']);
  $param['type']    = implode(',', $param['type']);
  $param['name']    = implode(',', $param['name']);
  $param['id_type'] = implode(',', $param['id_type']);
  $param['id_no']   = implode(',', $param['id_no']);
  $train = new TrainApi();
  $train->method('train/Order/confirm');
  $data = $train->action($param);
  echo json_encode($data);
  exit();
}

// 订单等待
if ($_GET['action'] == 'waitTime') {
  $param = $_POST;
  $param['session'] = $_SESSION['session'];
  $train = new TrainApi();
  $train->method('train/Order/waitTime');
  $data = $train->action($param);
  echo json_encode($data);
  exit();
}

// 进入队列
if ($_GET['action'] == 'returnQueue') {
  $param = $_POST;
  $param['session'] = $_SESSION['session'];
  $train = new TrainApi();
  $train->method('train/Order/returnQueue');
  $data = $train->action($param);
  echo json_encode($data);
  exit();
}