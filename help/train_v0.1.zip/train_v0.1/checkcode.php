<?php
// 校验验证码
session_start();
header('Content-Type: text/html; charset=utf-8');
require 'model/TrainApi.php';

$param = array();
$param['session']  = $_SESSION['session'];
$param['randCode'] = $_POST['randCode'];
$param['token']    = $_POST['token'];

$module = strtolower($_GET['module']);
if ($module == 'login') {
  $method = 'Train/Login/checkCode';
} elseif ($module == 'passenger') {
  $method = 'Train/Order/checkCode';
} else {
  echo '["errMsg":"提交参数错误！"]';
  exit();
}

$train = new TrainApi();
$train->method($method);
$data = $train->action($param);
echo json_encode($data);
