<?php
session_start();
unset($_SESSION['username']);
unset($_SESSION['session']);
header('location:login.php');