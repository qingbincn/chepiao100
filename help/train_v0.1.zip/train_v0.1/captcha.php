<?php 
// 验证码
session_start();
//header('Content-type: image/jpg');
require 'model/TrainApi.php';

$module  = $_GET['module'];
$session = $_SESSION['session'];

$train = new TrainApi();
$train->method('train/Captcha/'.$module);
$data = $train->action(array('session'=>$session));
echo base64_decode($data['base64']);