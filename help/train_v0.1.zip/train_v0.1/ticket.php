<?php require 'header.php';?>
<?php require 'session.php';?>
<?php
if (!empty($_GET['from_station'])&&!empty($_GET['to_station'])&&!empty($_GET['train_date'])){
  $param = $_GET;
  $param['session'] = $_SESSION['session'];
  $train = new TrainApi();
  $train->method('train/Ticket/left');
  $data = $train->action($param);
}

?>

<style>
table td{border-bottom:#DDD solid 2px;}
</style>

<div class="form wrap800">
   <h1>车票预定：</h1>
   <div class="errMsg"><?php if($data['errMsg']!='Y') echo $data['errMsg']; ?></div>
   <div class="search">
    <form id="postForm" name="postForm" method="get" action="ticket.php">
    出发站：<input type="text" id="from_station" name="from_station" value="<?php echo $_GET['from_station']; ?>" class="station"/>
    目的地：<input type="text" id="to_station" name="to_station" value="<?php echo $_GET['to_station']; ?>" class="station"/>
    出发日：<input type="text" id="train_date" name="train_date" value="<?php echo $_GET['train_date']; ?>" />
    <input type="submit" value="搜索"/>
    </form>
  </div>
  <?php if (is_array($data['data'])):?>
  <table width="100%" height="0" border="0" cellpadding="0" cellspacing="0" style="margin-top:10px;">
       <tr >
	      <th>车次</th>
		  <th>出发站<br/>到达站</th>
		  <th>出发时间<br/>到达时间</th>
		  <th>余票</th>
          <th>价格</th>
		  <th width="80px">备注</th>
	   </tr>
       <?php foreach ($data['data'] as $key=>$val): ?>
       <tr>
         <td><?php echo $val['train_code']; ?></td>
         <td><?php echo $val['from_station'].'<BR/>'.$val['to_station']; ?></td>
         <td><?php echo $val['start_time'].'<BR/>'.$val['arrive_time']; ?></td>
         <td>
           <?php foreach ($val['yp_info'] as $yp): ?>
           <?php echo $yp['na'].':'.$yp['yp'];?><br/>
           <?php endforeach; ?>
         </td>
         <td>价格</td>
         <td>
           <?php if ($val['can_buy'] == 'Y'): ?>
             <a href="javascript:doOrderBook('<?php echo $val['order_token']; ?>');" class="bookBtn"><?php echo $val['button_text']; ?></a>
           <?php else: ?>
              <div class="message">
                 <?php echo $val['button_text']; ?>
             </div>
           <?php endif; ?>
         </td>
       </tr>
       <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<form id="submitForm" name="submitForm" method="post" action="order-booking.php">
<input type="hidden" name="from_station" value="<?php echo $_GET['from_station']; ?>" class="station"/>
<input type="hidden" name="to_station" value="<?php echo $_GET['to_station']; ?>" class="station"/>
<input type="hidden" name="train_date" value="<?php echo $_GET['train_date']; ?>" />
<input type="hidden" name="token" id="submitToken" value="" />
</form>

<script type="text/javascript">
// 表单提交
var doOrderBook = function(token) {
    $('#submitToken').val(token);
	$('#submitForm').submit();
}
</script>
<?php require 'bottom.php';?>