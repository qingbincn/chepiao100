<?php
// 校验验证码
session_start();
header('Content-Type: text/html; charset=utf-8');
require 'model/TrainApi.php';

// 未完成订单取消
if ($_GET['action'] == 'cancel') {
  $param = array();
  $param['session'] = $_SESSION['session'];
  $param['sequence_no'] = $_GET['sequence_no'];
  
  $train = new TrainApi();
  $train->method('train/Order/cancel');
  $data = $train->action($param);
  if ( $data['errMsg'] == 'Y'){
    echo '<script>alert("订单取消成功！");location.href = "order-no.php"; </script>';
  } else {
    echo '<script>alert("'.$data['errMsg'].'");location.href = "order-no.php"; </script>';
  }
  exit();
}

// 退票提醒
if ($_GET['action'] == 'affirm') {
  $param = array();
  $param['session'] = $_SESSION['session'];
  $param['token']   = $_POST['token'];
  
  $train = new TrainApi();
  $train->method('train/Order/affirm');
  $data = $train->action($param);
  
  echo json_encode($data);
  exit();
}

// 确认退票
if ($_GET['action'] == 'refund') {
  $param = array();
  $param['session'] = $_SESSION['session'];

  //$train = new TrainApi();
  //$train->method('train/Order/refund');
  //$data = $train->action($param);

  if ( $data['errMsg'] == 'Y'){
    echo '<script>alert("退票成功！");location.href = "order.php"; </script>';
  } else {
    echo '<script>alert("'.$data['errMsg'].'");location.href = "order-no.php"; </script>';
  }
  exit();
}