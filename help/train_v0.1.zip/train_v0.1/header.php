<?php 
session_start();
header('Content-Type: text/html; charset=utf-8');
require 'model/TrainApi.php';
error_reporting(E_ALL^E_NOTICE);
?>
<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>12306订票接口(测试版v0.1)</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link type="text/css" href="plugins/validate/css/screen.css" rel="stylesheet"/>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="plugins/validate/jquery.validate.js"></script>
<script type="text/javascript" src="plugins/validate/localization/messages_zh.js"></script>
</head>
<body>
<div class="header wrap800">
12306订票接口(测试版v0.1) | 用户：<?php echo $_SESSION['username']; ?>
<div class="menu">
<a href="ticket.php">车票预定</a>
<a href="order-no.php">订单管理</a>
<a href="logout.php">系统退出</a>
</div>
</div>
<hr/>