<?php require 'header.php';?>
<?php
// 初始化支付
if ($_GET['action']=="payInit"){
  $param = array();
  $param['session'] = $_SESSION['session'];
  $param['sequence_no'] = $_GET['sequence_no'];
  
  $train = new TrainApi();
  $train->method('train/Payment/payInit');
  $data = $train->action($param);
  
  if ( $data['errMsg'] == 'Y'){
    echo '<script>location.href = "payment.php?action=payCheck"; </script>';
  } else {
    echo '<script>alert("'.$data['errMsg'].'");location.href = "order-no.php"; </script>';
  }
  exit();
}

// 支付校验
if ($_GET['action']=="payCheck"){
  $param = array();
  $param['session'] = $_SESSION['session'];
  $param['sequence_no'] = $_GET['sequence_no'];
  
  $train = new TrainApi();
  $train->method('train/Payment/payCheck');
  $data = $train->action($param);
  
  if ( $data['errMsg'] == 'Y'){
    echo '<form name="postForm" id="postForm" method="post" action="payment.php">';
    echo '<input type="hidden" name="token" value="'.$data['token'].'">';
    echo '</form>';
    echo '<script>$("#postForm").submit();</script>';
  } else {
    echo '<script>alert("'.$data['errMsg'].'");location.href = "order-no.php"; </script>';
  }
  exit();
}

// 提交支付
if ($_GET['action']=="payBusiness")
{
  $param = array();
  $param['session'] = $_SESSION['session'];
  $param['token']   = $_POST['token'];
  $param['bankId']  = $_POST['bankId'];
  
  $train = new TrainApi();
  $train->method('train/Payment/payBusiness');
  $data = $train->action($param);
  
  if ( $data['errMsg'] == 'Y'){
    echo '<form name="postForm" id="postForm" method="post" action="'.$data['action'].'">';
    foreach ($data['myForm'] as $name=>$val){
      echo '<input type="hidden" name="'.$name.'" value="'.$val.'">';
    }
    echo '</form>';
    echo '<script>$("#postForm").submit();</script>';
  } else {
    echo '<script>alert("'.$data['errMsg'].'");location.href = "order-no.php"; </script>';
  }
  exit();
}

$param = array();
$param['session'] = $_SESSION['session'];
$param['token']   = $_POST['token'];

$train = new TrainApi();
$train->method('train/Payment/payGateway');
$data = $train->action($param);
if ( $data['errMsg'] != 'Y'){
  echo '<script>alert("'.$data['errMsg'].'");location.href = "order-no.php"; </script>';
  exit();
}
?>
<script type="text/javascript" src="plugins/trainCaptcha/js/trainCaptcha.js"></script>
<link type="text/css" href="plugins/trainCaptcha/css/trainCaptcha.css" rel="stylesheet"/>
<div class="form wrap800">
    <h1>支付方式：</h1>
    <form id="postForm" name="postForm" method="post" action="payment.php?action=payBusiness">
    <input type="hidden" name="token" value="<?php echo $data['token']; ?>" />
    <div class="paymentBanks">
      <ul>
        <?php foreach ($data['banks'] as $bankId=>$bankName): ?>
        <li>
          <label>
              <?php echo $bankName; ?>
              <input type="radio" name="bankId" id="bankId" value="<?php echo $bankId; ?>"  onClick="doPayment()"/>
          </label>
        </li>
        <?php endforeach; ?>
      </ul>
      <div style="clear:both"></div>
    </div>
    </form>
  </div>
</div>
<script type="text/javascript">
$(function(){
   $('#TrainCaptcha').TrainCaptcha({input:"randCode",imgUrl:"captcha.php?module=login"});
   
   $("#postForm").validate({ 
	    errorElement: "em",
	    errorPlacement: function(error, element) {
			var this_id = element.attr('id');
	        $(".vaildTip").html('');
	        error.appendTo( $(".vaildTip") );
	    },
	    success: function(label) {
	        label.text("通过信息验证！").addClass("success");
	    },
        rules: {
           bankId: {required: true}
        }
  });
});

// 表单提交
var doPayment = function()
{
  $('#postForm').submit();
}

</script>
<?php require 'bottom.php';?>