<?php
if (empty($_SESSION['session']) || empty($_SESSION['username'])) {
  header('location:login.php');
  exit();
}

$train = new TrainApi();
$train->method('train/Login/checkUser');
$data = $train->action(array('session'=>$_SESSION['session']));
if ($data['errMsg'] !='Y') {
  header('location:login.php');
  exit();
}