<?php
error_reporting(E_ALL^E_NOTICE);

/**
 * 接口处理类
 * 测试版：appKey & appSecret 可先填
 * 
 *
 */
class TrainApi
{
  
  /**
   * 授权ID
   * 
   * @var string
   */
   public $ACCESSID = '10000';
   
   /**
    * 授权KEY
    * 
    * @var string
    */
   public $ACCESSKEY = '9f6e6800cfae7749eb6c486619254b9c';
     
   /**
    * 客户端请求IP
    * 
    * @var string
    */
   public $ACCESSIP;
   
   /**
    * 接口地址
    * 
    * @var string
    */
   public $API = 'http://openapi.chepiao100.com';
   
   /**
    * 设置方法
    * 
    * @param string $method
    */
   public function method($method)
   {
     $this->ACCESSIP = $_SERVER['REMOTE_ADDR'];
     $this->API = $this->API.'/'.$method.'?'.rand(1000,9999);
   }
   
   /**
    * 接口请求
    * 
    * @param array $param
    * @return mixed
    */
   public function action($param = '')
   {
     $json = $this->http($this->API, $param);
     return json_decode($json, true);
   }
   
   /**
    * 取数据
    * 
    * @param string $url
    * @param array $post
    * @return mixed
    */
   private function http($url, $post = '')
   {
     
     $header = array(
         'Cache-Control:nocache',
         'Pragma:no-cache',
         'Expires:-1',
         'ACCESSID: '.$this->ACCESSID,
         'ACCESSKEY:'.$this->ACCESSKEY,
         'ACCESSIP:'.$this->ACCESSIP,
     );
     
     $ch = curl_init($url);
     curl_setopt($ch, CURLOPT_TIMEOUT, 60);
     curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
     curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
     if (!empty($post)) {
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
     }
     $html = curl_exec($ch);
     curl_close($ch);
     return $html;
   }  
}

/* End of class TrainApi */