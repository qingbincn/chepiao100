<?php require 'header.php';?>
<?php require 'session.php';?>
<?php
$train = new TrainApi();
$train->method('train/Order/noComplete');
$data = $train->action(array('session'=>$_SESSION['session']));
$orderData = $data['data'];
?>
<script type="text/javascript" src="plugins/confirm/js/dialog.js"></script>
<link rel="stylesheet" href="plugins/confirm/css/dialog.css" />

<div class="form wrap800">
    <?php if ($data['errMsg'] == 'Y') : ?>
    <div class="block">
       席位已锁定，请在 <span>30</span> 分钟内进行支付，完成网上购票。 支付剩余时间：<span id="ShowTime" class="ShowTime"></span>
    </div>
    <table width="100%" height="0" border="0" cellpadding="0" cellspacing="0" style="margin-top:10px;">
       <tr>
	      <th>订单号</th>
          <th>车次信息</th>
		  <th>席位信息</th>
		  <th>旅客信息</th>
		  <th>票款金额</th>
		  <th width="90px">车票状态</th>
	   </tr
      <tbody>
      <?php foreach ($orderData as $val): ?>
        <tr>
          <td><?php echo $val['sequence_no']; ?></td>
          <td>
           <?php echo $val['train_date'].' '.$val['start_time']; ?>开<br/>
           <?php echo $val['train_code']; ?> <?php echo $val['from_station']; ?>-<?php echo $val['to_station']; ?><br/>
          </td>
          <td>
          <?php echo $val['coach_name']; ?>车<br/>
          <?php echo $val['seat_name'];?><br/>
          <?php echo $val['type_name'];?>
          </td>
          <td>
          <?php echo $val['passenger']['name']; ?><br/>
          <?php echo $val['passenger']['type_name']; ?>
          </td>
          <td>
          <?php echo $val['ticket_name'];?><br/>
          <?php echo $val['ticket_price'];?>元
          </td>
          <td>
          <?php echo str_replace("(", "<br/>(", $val['ticket_status']);?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <div class="orderBtn">
        <a href="order-cancel.php?action=cancel&sequence_no=<?php echo $val['sequence_no']; ?>" onClick="return doDelete();" class="cannel">取消</a>
        <a href="javascript:doPayment('payment.php?action=payInit&sequence_no=<?php echo $val['sequence_no']; ?>')" class="confirm">支付</a>
    </div>
    <?php else: ?>
    <div class="errMsg"><?php echo $data['errMsg']; ?></div>
    <?php endif; ?>
</div>
<div class="dialog-box" style="display:none;"></div>
<script>
$(function(){
   countDown("<?php echo $val['count_down']; ?>");
});

var doPayment = function(url)
{
	var html = '<div class="dailogQueue" id="dailogQueue">';
	html += '<div class="loading"></div>';
	html += '<div class="content">';
	html += '支付完成前，请不要关闭此支付验证窗口。<br/>支付完成后，请根据您支付的情况点击下面按钮。';
	html += '</div>';
	html += '</div>';
   	var $d = $(".dialog-box");
	$d.dialog({
		title: '网上支付提示',	
		dragable:true,
		html: '', 						
		width: 500,					
		height: 200,				
		cannelText: '支付遇到问题',		
		confirmText: '支付完成',	
		showFooter:true,
		onClose: function(){
		  location.href = 'order-no.php';
		},
		onOpen: false,		
		onConfirm: function() {
			 location.href = 'order-no.php';
		},
		onCannel: function(){  	
			location.href = 'order-no.php';
		},
		getContent:function(){
			$d.find('.body-content').html(html);
		}
	}).open(); 
   
   window.open(url);
}

// 倒计时
var countDown = function(time) {
	time = parseInt(time);
	var m = Math.floor(time / 60);
	var s = Math.floor(time % 60);
	
	if (m < 10) {
	  m = "0" + m
	}
	if (s < 10) {
	  s = "0" + s
	}
	if (time > 0) {
	  timeMsg = "<strong>" + m + "分" + s + "秒</strong>"
	} else {
	  timeMsg = '<strong><font color="#FF0000">00秒</font></strong>';
	}
	
	time = time - 1;
	if (time >= 0) {
	  window.setTimeout('countDown("' + time + '")', 1000)
	} else {
	  timeMsg = '<strong><font color="#FF0000">00秒</font></strong>';
	  $('.orderBtn, .block').remove();
	}
	$("#ShowTime").html(timeMsg);
}

var doDelete = function()
{
  if (confirm('您确认取消订单吗？ \n 一天内3次申请车票成功后取消订单，当日将不能在网站购票。') == false){
    return false;
  }
}
</script>
<?php require 'bottom.php';?>