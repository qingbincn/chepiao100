<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
require 'model/TrainApi.php';
require 'session.php';
$param = array();
$param['token'] = $_GET['token'];
$param['session'] = $_SESSION['session'];
$train = new TrainApi();
$train->method('train/Ticket/price');
$data = $train->action($param);
?>
<!DOCTYPE>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>12306订票</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div class="form wrap200">
<?php if ($data['errMsg'] == 'Y'): ?>
   <table width="100%" height="0" border="0" cellpadding="0" cellspacing="0">
      <tr>
         <th>坐席</th>
         <th>价格</th>
      </tr>
      <?php foreach ($data['data'] as $val): ?>
      <tr>
        <td><?php echo $val['na']; ?></td>
        <td><?php echo $val['pr']; ?></td>
      </tr>
      <?php endforeach;?>
   </table>
<?php else: ?>
   <div class="errMsg"><?php echo $data['errMsg']; ?></div>
<?php endif; ?>
</body>
</html>
<?php require 'bottom.php';?>