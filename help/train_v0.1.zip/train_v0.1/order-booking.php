<?php require 'header.php';?>
<?php require 'session.php';?>
<?php
  // 乘客信息
  $train = new TrainApi();
  $train->method('train/Passengers/option');
  $data = $train->action(array('session'=>$_SESSION['session']));
  $passenger = $data['data'];
  
  // 车次信息
  $param = $_POST;
  $param['session'] = $_SESSION['session'];
  $train = new TrainApi();
  $train->method('train/Order/submit');
  $data = $train->action($param);
  
  if ( $data['errMsg'] != 'Y'){
    echo '<script>alert("'.$data['errMsg'].'");history.back(); </script>';
	  exit();
  }
  
  // 拆分数据  
  $train  = $data['train'];
  $ypInfo = $data['yp_info'];
  $leftDetail = $data['left_detail'];
  $token  = $data['token'];
?>
<script type="text/javascript" src="plugins/trainCaptcha/js/trainCaptcha.js"></script>
<link type="text/css" href="plugins/trainCaptcha/css/trainCaptcha.css" rel="stylesheet"/>


<script type="text/javascript" src="plugins/confirm/js/dialog.js"></script>
<link rel="stylesheet" href="plugins/confirm/css/dialog.css" />


<div class="form wrap800">
   <div class="trainInfo">
   <h1>车次信息：</h1>
    <div class="info">
    <?php echo $train['train_date']; ?>（<?php echo $train['train_week']; ?>）<?php echo $train['train_code']; ?><span>次</span>
    <?php echo $train['from_station']; ?><span>站</span>（<?php echo $train['start_time']; ?>开）—<?php echo $train['to_station']; ?><span>站（<?php echo $train['arrive_time']; ?>到）</span>
    </div>
    <div class="yp">
    <?php foreach ($leftDetail as $yp): ?>
      <?php echo $yp['na'].'(<span class="has">￥'.$yp['pr'].'元</span>)'.$yp['yp'];?>　
    <?php endforeach; ?>
    </div>
  </div>
  <div class="passengerInfo">
    <h1>乘客信息</h1>
    <ul>
        <?php foreach ($passenger as $pass): ?>
        <label id="pass_<?php echo $pass['id_no']; ?>">
            <input type="checkbox" value="<?php echo $pass['name'].'_'.$pass['id_type'].'_'.$pass['id_name'].'_'.$pass['id_no']; ?>" name="passenger" onClick="doPassengerAdd(this)"/>
			<?php echo $pass['name']; ?>
        </label>
        <?php endforeach; ?>
    </ul>
  </div>
  <form id="postForm" name="postForm" method="post" action="">
  <div class="ypinfo">
    <table width="100%" height="0" border="0" cellpadding="0" cellspacing="0">
      <tr>
         <th>席别 </th>
         <th>票种</th>
         <th>姓名</th>
         <th>证件类型</th>
         <th>证件号码</th>
         <th width="40px">操作</th>
      </tr>
    </table>
    <div class="add">
      <a href="javascript:doPassengerAjax()" target="_blank">+新增乘客</a>
    </div>
  </div>
  <div class="captchaInfo">
      <input type="hidden" id="randCode" name="randCode" value=""/>
      <div id="TrainCaptcha" class="TrainCaptcha"></div>
      <input type="button" value="提交订单" onClick="doSubForm()"/>
  </div>
  <input type="hidden" name="token" id="token" value="<?php echo $token; ?>" />
  </form>
  <div class="dialog-box" style="display:none;"></div>
  <div class="ajax-box" style="display:none;"></div>
</div>


<div class="ypinfo_html" style="display:none;">
<table>
  <tr id="<id_no>">
  <td>
     <select name="seat[]">
         <?php foreach ($ypInfo as $yp): ?>
         <option value="<?php echo $yp['id']?>"><?php echo $yp['na'].'('.$yp['pr'].'元)';?></option>
         <?php endforeach; ?>
     </select>
  </td>
  <td>
      <select name="type[]">
          <option value="1" <?php if($_GET['type']=="1") echo 'selected';?>>成人</option>
          <option value="2" <?php if($_GET['type']=="2") echo 'selected';?>>儿童</option>
          <option value="3" <?php if($_GET['type']=="3") echo 'selected';?>>学生</option>
          <option value="4" <?php if($_GET['type']=="4") echo 'selected';?>>军疾</option>
       </select>
  </td>
  <td>
      <span><name></span>
      <input type="hidden" name="name[]" value="<name>" />
  </td>
  <td>
     <span><id_name></span>
     <input type="hidden" name="id_type[]" value="<id_type>" />
  </td>
  <td>
     <span><id_no></span>
     <input type="hidden" name="id_no[]" value="<id_no>" />
  </td>
  <td onClick="doPassengerDel(this)" class="button">删除</td>
  </tr>
  </table>
</div>


<script type="text/javascript">
var ypinfo_html = '';
$(function(){
	ypinfo_html = $('.ypinfo_html table').html();
	$('#TrainCaptcha').TrainCaptcha({input:"randCode",imgUrl:"captcha.php?module=passenger"});
});

// 删除
var doPassengerDel = function(obj) {
	var  id_no = $(obj).parents('tr').attr('id').replace('yp_');
    $(obj).parents('tr').remove();
	$('#'+id_no).find('input').prop('checked', false);
}

// 选择
var doPassengerAdd = function(obj) {
	 
	 if ($('.ypinfo tr').size()==6) {
		 alert('最多只能购买5张车票!');
		 $(obj).prop('checked', false);
	     return;
	 }
	 var p = $(obj).val().split('_');
	 var name     = p[0];
	 var id_type  = p[1];
	 var id_name  = p[2];
	 var id_no    = p[3];
	 var html  = ypinfo_html;
	
    if ($(obj).prop('checked') == true) {
		html = html.replace(/<name>/g, name);
		html = html.replace(/<id_type>/g, id_type);
		html = html.replace(/<id_name>/g, id_name);
		html = html.replace(/<id_no>/g, id_no);
		$('.ypinfo>table').append(html);
    } else {
	    $('#yp_'+id_no).remove();
	}
}

// 表单提交
var doSubForm = function() {
	
    if ($('.ypinfo tr').size()==1) {
		 alert('请选择购票乘客!');
	     return;
	 }
	
    var randCode = $('#randCode').val();
    if (randCode == '') return;
  
    $.post('checkcode.php?module=passenger', {randCode:randCode}, function(data){
        data = JSON.parse(data);
		if (data.errMsg == 'Y') {
	        $('#randCode').data('flag', 'success').click();
			doPassengerOrder()
		} else {
		    $('#randCode').data('flag', 'failure').click();
	    }
    });
}

// 订单确认提交
var doPassgengerDialog = function(json)
{
	var data = json.data;
	var html = '<div class="dailogQueue" id="dailogQueue">本次列车剩余：<br/><br/>';
	for (var i in data){
	   html += data[i].na+'<span> '+data[i].yp+'</span>张 ';
	}
	html += '队列：<span>'+json.countT+'</span>';
	html += '</div>';

	var $d = $(".dialog-box");
	$d.dialog({
		title: '请核对以下信息',	
		dragable:true,
		html: '', 						
		width: 450,					
		height: 200,				
		cannelText: '取消',		
		confirmText: '确认',	
		showFooter:true,
		onClose: function(){
		  $('#randCode').data('flag', 'init').click();
		},
		onOpen: false,		
		onConfirm: function() {
			 var html = '<div class="loading"></div>';
			 html += '<div class="content">';
			 html += '订单已经提交，系统正在处理中，请稍等。<br/>';
			 html += '查看订单处理情况，请点<a href="order-no.php">"未支付订单</a>"';
			 html += '</div>';
	         $('#dailogQueue').html(html);
			 $(".dialog-box").find('.footer').remove();
			 $(".dialog-box").find('.body').css('height', 150);
			 doPassengerConfirm();
		},
		onCannel: function(){  	
			$('#randCode').data('flag', 'initial').click();
		},
		getContent:function(){
			$d.find('.body-content').html(html);
		}
	}).open(); 
}

// 订单校验
var doPassengerOrder = function() {
    var param = $("#postForm").serialize();
	$.post('order-submit.php?action=checkOrder', param, function(data){
        data = JSON.parse(data);
		if (data.errMsg == 'Y') {
	        doPassengerQueue();
		} else {
		   alert(data.errMsg); 
		}
	});
}

// 队列:只在单一订单时使用
var doPassengerQueue = function(seat) {
    var token = $('#token').val();
	$.post('order-submit.php?action=queueCount', {token:token}, function(data){
	   data = JSON.parse(data);
	    if (data.errMsg == 'Y') {
	        doPassgengerDialog(data);
		} else {
		   alert(data.errMsg); 
		}
	});
}

// 提交订单
var doPassengerConfirm = function() {
    var param = $("#postForm").serialize();
	$.post('order-submit.php?action=confirm', param, function(data){
		data = JSON.parse(data);
	    if (data.errMsg == 'Y') {
	        doPassengerWaitTime();
		} else {
		   alert(data.errMsg); 
		}
	});
}

// 订单等待
var doPassengerWaitTime = function() {
    var token = $('#token').val();
	$.post('order-submit.php?action=waitTime', {token:token}, function(data){
		data = JSON.parse(data);
	    if (data.errMsg == 'Y') {
			if (typeof(data.sequence_no) == 'string' && data.sequence_no!=""){
			     doPassengerReturn(data.sequence_no);
			} else {
				setTimeout("doPassengerWaitTime()",2000)
			}
		} else {
		   alert(data.errMsg); 
		}
	});
}

// 进入队列
var doPassengerReturn = function(sequence_no) {
    var token = $('#token').val();
	$.post('order-submit.php?action=returnQueue', {token:token,sequence_no:sequence_no}, function(data){
	   data = JSON.parse(data);
	   if (data.errMsg == 'Y') {
           location.href = "order-no.php";
	   }
	});
}

// 添加用户
var doPassengerAjax  = function() {
    var html = '<iframe src="passengers-ajax.php" style="width:'+500+';height:'+500+'" frameborder=0 marginheight=0 marginwidth=0 scrolling=no></iframe>';
  	var $d = $(".ajax-box");
	$d.dialog({
		title: '添加乘客',	
		dragable:true,
		html: '', 						
		width: 550,					
		height: 510,				
		showFooter:false,
		getContent:function(){
			$d.find('.body-content').html(html);
		}
	}).open(); 
  
}
</script>
<?php require 'bottom.php';?>